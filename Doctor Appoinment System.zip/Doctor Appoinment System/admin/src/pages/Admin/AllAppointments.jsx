import React from 'react'

export default function AllAppointments() {
  return (
    <div>
      
    </div>
  )
}
